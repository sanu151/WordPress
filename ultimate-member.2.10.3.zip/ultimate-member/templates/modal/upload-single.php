<?php
/**
 * Template for the modal form
 *
 * This template can be overridden by copying it to your-theme/ultimate-member/modal/upload-single.php
 *
 * @version 2.8.6
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="um_upload_single" style="display:none;"></div>
