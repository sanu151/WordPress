<?php
/**
 * Features list start template
 */
?>
<div class="brands-list col-row">