     _ _
    | \ | ___  _ _ _  ___ ___  ___  ___  ___  _ _
    |   |/ ._>| | | |<_-<| . \<_> || . \/ ._>| '_>
    |_\_|\___.|__/_/ /__/|  _/<___||  _/\___.|_|
                         |_|       |_|
    ~ tagDiv 2025 ~


The documentations is here: 

https://forum.tagdiv.com/newspaper-theme-documentation/


Thanks for your support and feel free to contact us any time :) . 
Our support forum is here:
https://forum.tagdiv.com/



~ tagDiv 2025 ~