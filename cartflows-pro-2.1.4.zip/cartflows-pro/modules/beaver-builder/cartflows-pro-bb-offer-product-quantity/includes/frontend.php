<?php
/**
 * Frontend view
 *
 * @package offer-product-quantity
 */

?>
<div class="cartflows-pro-bb__offer-product-quantity cartflows-bb__offer-product-quantity_align-<?php echo esc_attr( $settings->align ); ?>">
	<?php
		echo do_shortcode( '[cartflows_offer_product_quantity]' );
	?>
</div>
